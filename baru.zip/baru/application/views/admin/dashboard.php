<div class="home">
  <center>
    <h1>E-Keuangan Seminari Garum</h1>
    <h2>Layanan Administrasi Keuangan Seminari Garum</h2>
    <h2>Jln. Merdeka Timur 4-6 Garum Blitar </h2>
    <img src="<?php echo base_url() ?>assets/images/a.jpg">
    <h2>Seminari Menengah St.Vincentius a Paulo</h2>
    <h2>Garum-Blitar</h2>
  </center>
  </div>