	<div style="text-align: center">
		
	<h1 text-align="center"> PEDOMAN </h1>
		
		<div>
			<img src="<?= base_url() ?>assets/images/p_1.jpeg">
		</div>
		<div>
			<img src="<?= base_url() ?>assets/images/p_2.jpeg">
		</div>
	</div>
