<?php 

/**
 * 
 */
class pdf
{
	
	function __construct(argument)
	{
		include_once APPPATH. '/third_party/fpdf/fpdf.php';
	}
}
 ?>